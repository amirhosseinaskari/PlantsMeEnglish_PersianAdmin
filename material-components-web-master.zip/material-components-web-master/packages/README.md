This folder contains all of our individual components as npm packages, along with the comprehensive
`material-components-web` package.
