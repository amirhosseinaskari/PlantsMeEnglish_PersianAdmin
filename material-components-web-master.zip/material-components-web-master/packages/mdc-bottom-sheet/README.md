# Bottom Sheet

The [Bottom Sheet component](https://material.io/go/design-sheets-bottom) is yet to be completed, please follow the [tracking issue](https://github.com/material-components/material-components-web/issues/2661) for more information.

