# Backdrop 

The [Backdrop component](https://material.io/go/design-backdrop) is yet to be completed, please follow the [tracking issue](https://github.com/material-components/material-components-web/issues/2656) for more information.

